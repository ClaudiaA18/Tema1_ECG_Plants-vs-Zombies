#pragma once

// #include "lab_m1/TEMA_1/lab3.h"
// #include "lab_m1/TEMA_1/lab3_vis2D.h"

#include "lab_m1\TEMA 1\Tema1.h"
